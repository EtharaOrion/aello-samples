"""High-level orchestration: assemble graded pieces -> aggregate -> write reward.

A task's tests/verifier.py computes S_outcome (family-specific, measured), runs the
pytest checks (deterministic), builds a sealed council context, then calls
score_and_write(...). This module ties the pieces to the one aggregate() function.
"""
from __future__ import annotations

import json
import os
from pathlib import Path

from .aggregate import RubricResult, aggregate
from .schema import RubricSet


def assemble(
    rubric_set: RubricSet,
    check_results: list[dict] | None,
    council_scores: dict[str, float] | None,
) -> list[RubricResult]:
    """Build the RubricResult list for aggregate() under the SPLIT model.

    - Deterministic rubrics are authoritative from check_results.json: the @check
      markers in test_output.py are the single source of truth for the pytest side
      (id/score/weight/knockout/kind). rubrics.json does NOT carry them.
    - Council rubrics come from the RubricSet (rubrics.json is council-only).
      Missing council scores fail closed (0.0) -- an ungraded behaviour gets no
      free credit.
    - The outcome is the measured base, passed to aggregate() separately, not here.
    """
    council_scores = council_scores or {}
    out: list[RubricResult] = []

    # Deterministic (pytest) side -- self-describing @check results.
    for c in (check_results or []):
        out.append(RubricResult(
            id=str(c["id"]),
            score=float(c.get("score", 0.0)),
            weight=int(c.get("weight", 1)),
            knockout=bool(c.get("knockout", False)),
            grader="pytest",
            kind=str(c.get("kind", "process")),
        ))

    # Non-deterministic (council) side -- council rubrics from rubrics.json.
    # Membership is bound to the declared council set and resolved normalization-invariantly:
    # a name-normalization divergence between rubric id and council key no longer silently
    # scores 0.0 (which, on a knockout, would collapse the whole reward), and a genuinely
    # ungraded council rubric raises CouncilOutage so the grade is WITHHELD as invalid rather
    # than fabricated as a knockout-zero. Closes G-VER-INVARIANCE (score.py:50).
    from .council import CouncilOutage

    def _norm(s):
        return str(s).strip().lower()

    council_norm = {_norm(k): v for k, v in council_scores.items()}
    for r in rubric_set.rubrics:
        if r.grader != "council":
            continue
        key = _norm(r.id)
        if key not in council_norm:
            raise CouncilOutage(
                "council produced no score for declared rubric %r (have: %s)"
                % (r.id, sorted(council_scores)))
        cs = float(council_norm[key])
        score = (1.0 if cs >= 0.5 else 0.0) if r.knockout else cs
        out.append(RubricResult(id=r.id, score=score, weight=r.weight,
                                knockout=r.knockout, grader="council", kind=r.kind))
    return out


def write_reward(reward: float, detail: dict, log_dir: str | Path | None = None) -> Path:
    d = Path(log_dir) if log_dir else Path(os.environ.get("HARBOR_VERIFIER_LOG_DIR", "/logs/verifier"))
    d.mkdir(parents=True, exist_ok=True)
    # Harbor reads reward.json as rewards: dict[str, number] -- numeric only.
    (d / "reward.json").write_text(json.dumps({"reward": float(reward)}) + "\n")
    (d / "reward.txt").write_text(f"{float(reward):.6f}\n")
    (d / "reward_detail.json").write_text(json.dumps(detail, indent=2, sort_keys=True) + "\n")
    return d / "reward.json"


def score_and_write(
    *,
    rubric_set: RubricSet,
    outcome_score: float,
    floor: float = 0.5,
    check_results: list[dict] | None = None,
    council_scores: dict[str, float] | None = None,
    log_dir: str | Path | None = None,
) -> tuple[float, dict]:
    """Full path: assemble -> aggregate -> write /logs/verifier/reward.{json,txt} + detail."""
    results = assemble(rubric_set, check_results, council_scores)
    reward, detail = aggregate(outcome_score=outcome_score, rubrics=results, floor=floor)
    write_reward(reward, detail, log_dir)
    return reward, detail
